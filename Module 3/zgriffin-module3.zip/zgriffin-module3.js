<!DOCTYPE html>

<html lang='en'>

    <!--

       Zachary Griffin

       Bellevue University Student

    -->

    <head>

      …

       <script>

           var firstVariableValue = "travel";

       </script>

       </head>

       <body>

       …


       <p> In my life I was born and raised in Boston. I attended public schools until I went 
           to ITT Tech when I was 19. That school was infamous for closing its doors in 2017
           for financial bankrupcy related reasons. Later, I atteneded Emerson College for a certificate
           in data science and now I am in Bellevue to get a new Bachelor's degeree in software
           development. I currently work as a robotics designer and technician and I want
           to learn more in programming to advance my career. I also like to <span id = "travel">
______________________________ </span>
       </p>

       <p>

           <button type="button"
             onclick="document.getElementById('travel').innerHTML = firstVariableValue">travel</button> <br />
       </p>
    …

 </body>
</html>